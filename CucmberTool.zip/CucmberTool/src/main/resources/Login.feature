Feature: Login Functionality

  Scenario Outline: Check Login with valid credentials
    Given  User navigated to Login Page
    When  User Enter Valid "<Username>" and Valid "<Password>"
    Then User can See Welcome in Home Page

  Examples:
  | Username| Password|
  |fady123  | 123     |
  |fady123  | 12     |
  |ahmed123  | 123     |
  |ahmed123  | 12     |


#    Scenario: Check Login with invalid credentials
#      Given  User navigated to Login Page
#      When  User Enter Invalid Username and Invalid Password
#      Then Error message should appear says incorrect username and password