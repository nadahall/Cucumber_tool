package MyPages;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class LoginPage {
    WebDriver Browser;
    WebDriverWait MyWait;
    public final By Username= By.id("loginusername");
    public final By Password= By.id("loginpassword");
    public final By LoginButton= By.cssSelector("[onclick=\"logIn()\"]");
    public final By CloseButton= By.xpath("(//button[text()=\"Close\"])[3]");

    public final By LoginPageTitle= By.id("logInModalLabel");


    public LoginPage(WebDriver Browser){
        this.Browser=Browser;
        MyWait=new WebDriverWait(Browser, Duration.ofSeconds(8));
    }
   public void Enter_Username(String EnteredUsername) {
        MyWait.until(ExpectedConditions.visibilityOfElementLocated(Username));
        Browser.findElement(Username).sendKeys(EnteredUsername);
   }

    public void Enter_Password(String EnteredPassword) {
        MyWait.until(ExpectedConditions.visibilityOfElementLocated(Password));
        Browser.findElement(Password).sendKeys(EnteredPassword);
    }

    public void Click_on_loginButton() {
        MyWait.until(ExpectedConditions.visibilityOfElementLocated(LoginButton));
        Browser.findElement(LoginButton).click();
    }
    public void Click_on_CloseButton() {
        MyWait.until(ExpectedConditions.visibilityOfElementLocated(CloseButton));
        Browser.findElement(CloseButton).click();
    }
    public boolean CheckLoginTitleIsDisplayed(){
        MyWait.until(ExpectedConditions.visibilityOfElementLocated(LoginPageTitle));
       return Browser.findElement(LoginPageTitle).isDisplayed();
    }
    public String GetAlertText(){

        Alert alert=  MyWait.until(ExpectedConditions.alertIsPresent());;
        return alert.getText();
    }
}
