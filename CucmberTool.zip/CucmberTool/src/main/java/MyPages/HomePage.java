package MyPages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.Browser;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.List;

public class HomePage {
    WebDriver browser ;
    WebDriverWait wait;
    public final By Categories = By.cssSelector("div.list-group>a[id=\"itemc\"]");
    public final By SignupButton= By.id("signin2");
    public final By LoginButton= By.id("login2");
    public final By CartButton= By.id("cartur");
    public final By RightCursor= By.className("carousel-control-next-icon");

    public final By Allphoneslocator = By.cssSelector("[class=\"col-lg-4 col-md-6 mb-4\"]");
    public final By Welcomemessage=By.id("nameofuser");
public  HomePage(WebDriver browser)
{
    this.browser=browser;
    wait=new WebDriverWait(browser, Duration.ofSeconds(10));
}
public  void  ClickOnRightCursor(){
    wait.until(ExpectedConditions.visibilityOfElementLocated(RightCursor));
    browser.findElement(RightCursor).click();
}
public void Click_On_Category(int index){
    wait.until(ExpectedConditions.visibilityOfElementLocated(Categories));
    List<WebElement> All_Categories= browser.findElements(Categories);
    All_Categories.get(index).click();
}

public void ClickonLoginButton(){
    wait.until(ExpectedConditions.visibilityOfElementLocated(LoginButton));
    browser.findElement(LoginButton).click();
    }
    public void ClickonSignupButton(){
        wait.until(ExpectedConditions.visibilityOfElementLocated(SignupButton));
        browser.findElement(SignupButton).click();
    }
    public void ClickonCartButton(){
        wait.until(ExpectedConditions.visibilityOfElementLocated(CartButton));
        browser.findElement(CartButton).click();
    }

public int GetNumbeerrOFallPhones(){
    wait.until(ExpectedConditions.visibilityOfElementLocated(Allphoneslocator));
        return wait.until(ExpectedConditions.visibilityOfAllElements(browser.findElements(Allphoneslocator))).size();

}
public String GetWelcomemessage(){
    wait.until(ExpectedConditions.visibilityOfElementLocated(Welcomemessage));
    return browser.findElement(Welcomemessage).getText();
}
}
