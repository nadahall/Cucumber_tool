package StepsDefinition;

import Hooks.hooks;
import MyPages.HomePage;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.testng.Assert;

public class HomePageSteps {
    HomePage myhomepage= new HomePage(hooks.Browser);
    @Given("User navigated to Home Page")
    public void VerifyThatUserNavigatedToHomePage(){
        Assert.assertEquals(hooks.Browser.getCurrentUrl(),"https://www.demoblaze.com/");
    }
    @When("User Click on Phones Category")

        public void VerifyThatUserClickedonPhonesCategory(){
myhomepage.Click_On_Category(0);
    }
    @Then("Products should be filtered with phones only")
    public void VerifyThatProductsIsFilteredByPhones(){
Assert.assertEquals(myhomepage.GetNumbeerrOFallPhones(), 7);
    }

    @When("User Click on Laptops Category")
    public void VerifyThatUserClickedonlaptopCategory(){

    }
    @Then("Products should be filtered with Laptops only")
    public void VerifyThatProductsIsFilteredBylaptops(){

    }

}
