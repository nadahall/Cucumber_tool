package StepsDefinition;

import Hooks.hooks;
import MyPages.HomePage;
import MyPages.LoginPage;
import io.cucumber.java.Before;
import io.cucumber.java.PendingException;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.testng.Assert;

public class LoginPageSteps {
    HomePage MyHomePage =new HomePage(hooks.Browser);
    LoginPage MyLoginPage;

    @Before(order=2)
    public void Precondition_BeforeLoginScenario(){
        MyHomePage.ClickonLoginButton();
        MyLoginPage=new LoginPage(hooks.Browser);
    }



    @Given("User navigated to Login Page")
    public void UserCanSeeWelcomeInHomePage(){
        Assert.assertEquals(MyLoginPage.CheckLoginTitleIsDisplayed(),true);
    }

    @When("User Enter Valid {string} and Valid {string}")
    public void userEnterValidAndValid(String Username, String Password) {
        MyLoginPage.Enter_Username(Username);
        MyLoginPage.Enter_Password(Password);
        MyLoginPage.Click_on_loginButton();
    }



    @Then("User can See Welcome in Home Page")
    public void userCanSeeWelcomeInHomePage() {
Assert.assertEquals(MyHomePage.GetWelcomemessage(),"Welcome fady123");

    }

    @When("User Enter Invalid Username and Invalid Password")
    public void userEnterInvalidUsernameAndInvalidPassword() {
        MyLoginPage.Enter_Username("123");
        MyLoginPage.Enter_Password("544");
        MyLoginPage.Click_on_loginButton();

    }

    @Then("Error message should appear says incorrect username and password")
    public void errorMessageShouldAppearSaysIncorrectUseernameAndPassword() {
Assert.assertEquals(MyLoginPage.GetAlertText(),"username or password is incorrect");
    }


}
