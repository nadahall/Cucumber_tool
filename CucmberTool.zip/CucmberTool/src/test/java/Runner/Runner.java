package Runner;

import io.cucumber.core.backend.StepDefinition;
import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;


@CucumberOptions(
        features = "src/main/resources/Login.feature",
        glue = {"StepsDefinition", "Hooks" }

)

public class Runner extends AbstractTestNGCucumberTests {

}
