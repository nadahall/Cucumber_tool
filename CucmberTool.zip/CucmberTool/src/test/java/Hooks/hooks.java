package Hooks;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class hooks {
   public static WebDriver Browser;
    @Before(order = 1)
    public void  SetUP(){
        Browser=new ChromeDriver();
        Browser.get("https://www.demoblaze.com/");
        Browser.manage().window().maximize();

    }
    @After
    public void Quit(){
        Browser.quit();
    }
}
